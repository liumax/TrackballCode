

fileName = '151217_ML151211A_R17_2000_noSound';

extractSpikeBinaryFiles(fileName);

%this should create matclust file folder
createAllMatclustFiles